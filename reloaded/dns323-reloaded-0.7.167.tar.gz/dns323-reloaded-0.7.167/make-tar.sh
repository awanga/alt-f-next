#!/bin/sh

set -x
set -e

NAME=dns323-reloaded
test -e VERSION
VERSION=$(printf "%d.%d.%d" $(cat VERSION) $(date '+%y %j'))

CWD=$(pwd)
D=$(basename $CWD)

cd ..
rm -rf tartemp
mkdir tartemp
cp -aR $D tartemp/$NAME-$VERSION
cd tartemp/$NAME-$VERSION

cd ..
tar cf - \
    $NAME-$VERSION \
    | gzip -9 -c >$CWD/../$NAME-$VERSION.tar.gz
cd ..
rm -rf tartemp

